# File Organizer

**This file organizer is a computer program that provides user interface to manage files and folders.**

**The most common operations performed on files or groups of files include creating, opening (e.g. viewing, playing, editing or printing), renaming, copying, moving, deleting and searching for files, as well as modifying file attributes, properties and file permissions. Folders and files may be displayed in a hierarchical tree based on their directory structure.**

**This file organizer move multiple files by copying and deleting each selected file from the source individually.**

**This file organizer contain features analogous to web browsers**

  - **This file organizer is built based on the python programming language.**
  
  - **This file organizer is currently in its first version i.e 1.0 and later on it will be further go ahead.**

## Packages used in the project

- **Tkinter**

- **Firebase**

- **Pillow**

- **Datetime**

- **Webbrowser**

- **Shutil**

- **RE**

- **OS**

## Conditions for a valid username

- **The username consists of 6 to 30 characters inclusive. If the username consists of less than 6 or greater than 30 characters, then it is an invalid username.**

- **The username can only contain alphanumeric characters and underscores (_). Alphanumeric characters describe the character set consisting of lowercase characters [a – z], uppercase characters [A – Z], and digits [0 – 9].**

- **The first character of the username must be an alphabetic character, i.e., either lowercase character [a – z] or uppercase character [A – Z].**

## Conditions for a valid password

- **Should have at least one number.**

- **Should have at least one uppercase and one lowercase character.**

- **Should have at least one special symbol.**

- **Should be between 6 to 20 characters long.**
