from cx_Freeze import *
import sys
import os

base = None

# if sys.platform == "win32":
#     base = "win32GUI"

os.environ['TCL_LIBRARY'] = r'C:\Users\Piyush\AppData\Local\Programs\Python\Python38-32\tcl\tcl8.6'

os.environ['TK_LIBRARY'] = r'C:\Users\Piyush\AppData\Local\Programs\Python\Python38-32\tcl\tk8.6'

packages = ['os', 're', 'shutil', 'PIL', 'tkinter', 'datetime', 'webbrowser', 'firebase']
include_files = ['icon.xbm', 'tcl86t.dll', 'tk86t.dll', 'images']
executables = [Executable("main.py", base=base, icon="icon.xbm")]

setup(
    name="File Organizer",
    options={'build_exe': {'packages': packages, 'include_files': include_files}},
    version="1.0",
    description='This file organizer is a computer program that provides user interface to manage files and folders.',
    executables=executables
)
